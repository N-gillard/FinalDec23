const express = require('express');
const exphbs = require('express-handlebars');
const bodyParser = require('body-parser');
const { Pool } = require('pg');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const pgPool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'FishSprint',
  password: 'sudo -u postgres psql',
  port: 5432,
});

app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');
app.set('views', __dirname + '/views');

app.get('/', (req, res) => {
  res.render('index');
});

app.post('/search', async (req, res) => {
  const { query, sources } = req.body;

  const searchResults = await searchInDatabase(query, sources);

  res.render('search-results', { results: searchResults });
});

async function searchInDatabase(query, sources) {
  const results = await pgPool.query(`
    SELECT * FROM fishing_data
    WHERE fishname ILIKE $1
      AND location = ANY($2::text[]);
  `, [`%${query}%`, sources]);

  return results.rows.map(row => ({
    fishname: row.fishname,
    datecaught: row.anglername,
  }));
}
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
