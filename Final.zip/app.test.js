const { searchInDatabase } = require('./app');
const { Pool } = require('pg');

jest.mock('pg');
Pool.mockImplementation(() => ({
  query: jest.fn(),
}));

describe('searchInDatabase function', () => {
  it('should return search results', async () => {
    Pool().query.mockResolvedValue({
      rows: [
        { column_name: 'Result 1' },
        { column_name: 'Result 2' },
      ],
    });

    const results = await searchInDatabase('query', []);
    expect(results).toEqual(['Result 1', 'Result 2']);
  });

  it('should handle no results', async () => {
    Pool().query.mockResolvedValue({
      rows: [],
    });

    const results = await searchInDatabase('query', []);
    expect(results).toEqual([]);
  });

  afterAll(() => {
    jest.restoreAllMocks();
  });
});
