const express = require('express');
const { Pool } = require('pg');

const router = express.Router();

const pgPool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'FishSprint',
  password: 'sudo -u postgres psql', 
  port: 5432,
});

router.post('/search', (req, res) => {
  const { searchTerm, dataSource } = req.body;

  let query;

  if (dataSource === 'postgres') {

    query = {
      text: 'SELECT * FROM fishing_data WHERE fishname ILIKE $1',
      values: [`%${searchTerm}%`],
    };
  } else {
 
  }

  if (query) {
    pgPool.query(query)
      .then((result) => {
        console.log(result.rows);
        res.render('search', { results: result.rows });
      })
      .catch((error) => {
        console.error('Error executing query', error);
        res.render('search', { results: [] }); 
      });
  } else {
    res.render('search', { results: [] });
  }
});

module.exports = router;

